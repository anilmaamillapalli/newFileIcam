package org.ed.icam.oim.utils.entity;

public class Contractor {
    private String personalHandle;
    private String contractorEmpStatus;
    private String  firstName;
    private String lastName;
    private String middleName;
    private String ContractorCompany;
    private String bureauId;
    private String bureauDescription;
    private String positionSensitivity;
    private String corName;
    private String empType;


    public String getPersonalHandle() {
        return personalHandle;
    }

    public void setPersonalHandle(String personalHandle) {
        this.personalHandle = personalHandle;
    }

    public String getContractorEmpStatus() {
        return contractorEmpStatus;
    }

    public void setContractorEmpStatus(String contractorEmpStatus) {
        this.contractorEmpStatus = contractorEmpStatus;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getContractorCompany() {
        return ContractorCompany;
    }

    public void setContractorCompany(String contractorCompany) {
        ContractorCompany = contractorCompany;
    }

    public String getBureauId() {
        return bureauId;
    }

    public void setBureauId(String bureauId) {
        this.bureauId = bureauId;
    }

    public String getBureauDescription() {
        return bureauDescription;
    }

    public void setBureauDescription(String bureauDescription) {
        this.bureauDescription = bureauDescription;
    }

    public String getPositionSensitivity() {
        return positionSensitivity;
    }

    public void setPositionSensitivity(String positionSensitivity) {
        this.positionSensitivity = positionSensitivity;
    }

    public String getCorName() {
        return corName;
    }

    public void setCorName(String corName) {
        this.corName = corName;
    }

    public String getEmpType() {
        return empType;
    }

    public void setEmpType(String empType) {
        this.empType = empType;
    }

    @Override
    public String toString() {
        return "Contractor{" +
                "personalHandle=" + personalHandle +
                ", contractorEmpStatus='" + contractorEmpStatus + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", ContractorCompany='" + ContractorCompany + '\'' +
                ", bureauId='" + bureauId + '\'' +
                ", bureauDescription='" + bureauDescription + '\'' +
                ", positionSensitivity='" + positionSensitivity + '\'' +
                ", corName='" + corName + '\'' +
                ", empType='" + empType + '\'' +
                '}';
    }
}
