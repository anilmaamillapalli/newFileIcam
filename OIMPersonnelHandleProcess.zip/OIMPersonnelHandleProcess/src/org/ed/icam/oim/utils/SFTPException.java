package org.ed.icam.oim.utils;

public class SFTPException extends Exception{
    SFTPException(String s){
        super(s);
    }
}
