package org.ed.icam.oim.utils;

import oracle.iam.platform.OIMClient;

import javax.security.auth.login.LoginException;
import java.util.Hashtable;

public class OIMUtils {
    public static OIMClient BaseClient() {
        //  logger.log(ODLLevel.INFO,"====I am in the BaseClient Method which return OIMCleint=======");
        final String OIMUSERNAME = "xelsysadm";
        final String OIMPASSWORD = "Password1";
        System.setProperty("APPSERVER_TYPE", "wls");
        System.setProperty("java.security.auth.login.config", "C:\\Users\\anilm\\Documents\\designconsole\\config\\authwl.conf");
        System.setProperty("OIM.AppServerType", "wls");
        System.setProperty("APPSERVER_TYPE", "wls");
        Hashtable<String, String> env = new Hashtable<String, String>();
        env.put(OIMClient.JAVA_NAMING_FACTORY_INITIAL, "weblogic.jndi.WLInitialContextFactory");
        env.put(OIMClient.JAVA_NAMING_PROVIDER_URL, "t3://192.168.195.128:14000");
        OIMClient oimClient = new OIMClient(env);
        try {
            oimClient.login(OIMUSERNAME, OIMPASSWORD.toCharArray());
            System.out.println("Connected to OIM");

            //logger.log(ODLLevel.INFO,"=========Connection extablished to OIM Successfully===========");
        } catch (LoginException e) {
            // logger.log(ODLLevel.SEVERE,"",e);
            System.out.println(e);
        }
        return oimClient;
    }

    public static boolean isEmpty(String value) {
        return (value == null) || ((String) value).trim().equals("");
    }
    public static void main(String[] args){
        BaseClient();
    }

}
