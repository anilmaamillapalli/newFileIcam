package org.ed.icam.oim.utils;

import com.csvreader.CsvReader;
import com.jcraft.jsch.*;
import groovy.json.internal.Charsets;
import oracle.core.ojdl.logging.ODLLogger;
import oracle.iam.identity.exception.NoSuchUserException;
import oracle.iam.identity.exception.UserModifyException;
import oracle.iam.identity.exception.UserSearchException;
import oracle.iam.identity.exception.ValidationFailedException;
import oracle.iam.identity.usermgmt.api.UserManager;
import oracle.iam.identity.usermgmt.vo.User;
import oracle.iam.platform.entitymgr.vo.SearchCriteria;
import oracle.iam.scheduler.vo.TaskSupport;
import org.ed.icam.oim.utils.constants.OIMConstants;
import org.ed.icam.oim.utils.entity.Contractor;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Project Name		 	       : Enterprise ICAM
 * Copyright		 		   : Mythics Emergent Group
 * Company		 	 	       : Mythics Emergent Group
 * Version		 	 	       : 1.0
 * File Name		 		   : UpdatePersonalHandleNo
 * Environment                 : OIM 12c PS3
 * Description / Purpose 	   : Connect Remote SFTP Server to get CSV File and process the given data and create local CSV File.
 *                               for the updating the "Personnal Handle","Contractor Company Name","Bureau ID" for the given users.
 * Extends             	       : TaskSupport
 *
 * Modified Details			:
 *
 * Ver. No.	         Modified by     	            Date  	       Why & What is modified       Certified By
 *
 * 1.0           Maamillapalli Anil(MAK)          02-23-2022                 INITIAL         Bhimaraju,Chandra
 *
 */
public class UpdatePersonalHandleNo  extends TaskSupport {
    private static final Logger logger = ODLLogger.getLogger(UpdatePersonalHandleNo.class.getName());

    /**
     * @param hashMap
     * @throws Exception
     * Description :  Triggering(Starting) point for this process
     */
    @Override
    public void execute(HashMap hashMap) throws Exception {
        logger.log(Level.INFO,"===================Executing execute method of UpdatePersonalHandleNo==========================");

        String sftp_host_name =(String) hashMap.get("SFTP Host Name");
        logger.log(Level.INFO,"SFTP SERVER HOST NAME :::"+sftp_host_name);

        String remote_csv_file_path =(String)hashMap.get("Remote CSV File Path");
        logger.log(Level.INFO,"REMOTE SERVER FILE PATH :::"+remote_csv_file_path);

        String sftp_user_name =(String)hashMap.get("SFTP User Name");
        logger.log(Level.INFO,"SFTP USER NAME :::"+sftp_user_name);

        String sftp_password = (String) hashMap.get("SFTP Password");
        logger.log(Level.INFO,"SFTP Password :::"+sftp_password.hashCode());

        String sftp_HostKey=(String)hashMap.get("SFTP HostKey");
        logger.log(Level.FINEST,"AUTHORIZATION  KEY folder path to Connect SFTP Server:::"+sftp_HostKey);

//todolist
        String local_csv_file_path =(String)hashMap.get("Local CSV File Path");
        logger.log(Level.INFO,"LOCAL CSV FILE PATH :::"+local_csv_file_path);

        String destinationFilePath= (String)hashMap.get("Destination File Path");
        logger.log(Level.INFO,"Local PATH to SAVE FILE :::"+destinationFilePath);

        //passing the control to below method
        String localFileName= ProcessingRemoteCSVFile(remote_csv_file_path,sftp_user_name,sftp_password,sftp_host_name,sftp_HostKey);
        logger.log(Level.INFO,"LOCAL CSV FILE PATH :::"+local_csv_file_path);

    }

    /**
     * @param remote_csv_file_path
     * @param sftp_user_name
     * @param sftp_password
     * @param sftp_host_name
     * @param sftp_HostKey
     * @return
     * Description : Connecting to Remote SFTP Server by passing above attributes and gets InputStream and passing to next method
     */
    private String ProcessingRemoteCSVFile(String remote_csv_file_path,String sftp_user_name,String sftp_password,String sftp_host_name,String sftp_HostKey) {
        Properties config = new Properties();
        JSch jsch = new JSch();
        try {
            jsch.setKnownHosts(sftp_HostKey);
            Session session = jsch.getSession(sftp_user_name, sftp_host_name);
            session.setPassword(sftp_password);
            session.setConfig(config);
            session.connect();
            logger.log(Level.INFO,"=======Starting SFTP Server Session ======== ");
            ChannelSftp channelSftp = (ChannelSftp) session.openChannel(OIMConstants.SFTP);
            channelSftp.connect();
            InputStream inputStream= null;
            if(!channelSftp.isConnected()){
                logger.log(Level.SEVERE,"@@@@@@ Could not able to connect Remote SFTP Server @@@@@@@ ");
                throw new IOException(OIMConstants.SFTP_CLIENT_NOTCONNECTED);
            }else{
                logger.log(Level.INFO,"=======Connected to Remote SFTP Server ======== ");
                inputStream = channelSftp.get(remote_csv_file_path);
                logger.log(Level.INFO,"======= inputstream is ready to ready data from the data pipe  ======== ");

                //Transfer the file to local environment
                //

                //passing the control and getting back
                List<Contractor> listContractor = getContractorInformationFromCSVFile(inputStream);
                if(listContractor != null) {
                    searchUpdateUser(listContractor);
                }

            }
        } catch (JSchException e) {
            e.printStackTrace();
        } catch (SftpException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @param remoteInputStream
     * @return
     * Description: This method takes InputStream and generates List object of Contractors.
     */
    private List<Contractor> getContractorInformationFromCSVFile(InputStream remoteInputStream) {
        // InputStream is = new FileInputStream(localFilePath);
        //InputStream is = new FileInputStream("C:\\SM Contractor Identity_20211216.csv");
        CsvReader contractorFileReader = new CsvReader(remoteInputStream, OIMConstants.COMMA_DELIMITER, Charsets.UTF_8);
        List<Contractor> contactorList= null;
        try {
            contractorFileReader.readHeaders();
            contactorList= new ArrayList<Contractor>();
            Contractor contractor;
            while(contractorFileReader.readRecord()){
                contractor= new Contractor();
                contractor.setPersonalHandle(OIMConstants.PERSONNEL_HANDLE);
                contractor.setContractorEmpStatus(OIMConstants.CONTRACTOR_EMP_STATUS);
                contractor.setFirstName(OIMConstants.FIRST_NAME);
                contractor.setLastName(OIMConstants.LAST_NAME);
                contractor.setMiddleName(OIMConstants.MIDDLE_NAME);
                contractor.setContractorCompany(OIMConstants.CONTRACTOR_COMPANY_NAME);
                contractor.setBureauId(OIMConstants.BUREAU_ID);
                contractor.setBureauDescription(OIMConstants.BUREAU_DESCRIPTION);
                contractor.setPositionSensitivity(OIMConstants.POSITION_SENSITIVITY);
                contractor.setCorName(OIMConstants.COR_NAME);
                contractor.setEmpType(OIMConstants.EMP_TYPE);
                contactorList.add(contractor);
            }
            System.out.println("List of user Information "+contactorList.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return contactorList;
    }

    /**
     * @param contractorList
     * @throws UserSearchException
     * @throws ValidationFailedException
     * @throws NoSuchUserException
     * @throws UserModifyException
     * Description:  This method Searches User Object in OIM If found call modify user methods for Updating user Personnel Handle Number and other attributes.
     */
    public static void  searchUpdateUser(List<Contractor> contractorList)  {
        SearchCriteria criteriaFirstName, criteriaLastName,criteriaResult;
        for (Contractor contractor: contractorList) {
            criteriaFirstName= new SearchCriteria("First Name",contractor.getFirstName(),SearchCriteria.Operator.EQUAL);
            criteriaLastName= new SearchCriteria("Last Name",contractor.getLastName(),SearchCriteria.Operator.EQUAL);
            criteriaResult= new SearchCriteria(criteriaFirstName, criteriaLastName, SearchCriteria.Operator.AND);

            //udpate user info
            Set fetchAttr= new HashSet();
            fetchAttr.add("First Name");
            fetchAttr.add("Last Name");
            fetchAttr.add("Personnel Handle");
            UserManager userManager = OIMUtils.BaseClient().getService(UserManager.class);

            List<User> oimUserList = null;
            try {
                oimUserList = userManager.search(criteriaResult, fetchAttr, null);
            } catch (UserSearchException e) {
                e.printStackTrace();
            }

            if(oimUserList.size() > 1){
                //If more than a User create record the CSV File.
                //check with chandra, what if the same record comes in a file  for the processing and Handle number is already presisted in the user profile.
                //Create CSV File
                //Enter this contractor's record to the file. because multiple records find in OIM.
            }else if (OIMUtils.isEmpty(oimUserList.get(1).getAttribute("Personnel Handle No").toString())){
                //check the personnal handle equal if not creat new file and save it into it.
                //if personal handle no exist do not update it but update other attribtues
                User user = oimUserList.get(1);
                //passing to below method
                modifyUserAttributes(user.getId(),contractor.getPersonalHandle(),contractor.getBureauId(),contractor.getContractorCompany());
            }else{
               // check with chandra,
            }
        }
    }

    /**
     * @param id
     * @param personalHandle
     * @param bureauId
     * @param contractorCompany
     * @throws ValidationFailedException
     * @throws NoSuchUserException
     * @throws UserModifyException
     * Description : This method is called from the caller in the loop to update user profile.
     */
    private static void modifyUserAttributes(String id, String personalHandle, String bureauId, String contractorCompany) {
        //this is the second time we are using UserManager.class can we make it as class level verable ....Think
        UserManager userManager = OIMUtils.BaseClient().getService(UserManager.class);
        User updateUser= new User(id);
        updateUser.setAttribute("AttributeName",personalHandle);
        updateUser.setAttribute("attributeName",bureauId);
        updateUser.setAttribute("attributeName", contractorCompany);
        try {
            userManager.modify(updateUser);
        } catch (ValidationFailedException e) {
            e.printStackTrace();
        } catch (UserModifyException e) {
            e.printStackTrace();
        } catch (NoSuchUserException e) {
            e.printStackTrace();
        }
    }
    @Override
    public HashMap getAttributes() {
        return null;
    }
    @Override
    public void setAttributes() {

    }

}
