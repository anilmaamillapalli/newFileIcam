package org.ed.icam.oim.utils.constants;

public class OIMConstants {

    public static final String PERSONNEL_HANDLE=  "Personnel Handle";
    public static final String CONTRACTOR_EMP_STATUS= "Contractor Employment Status";
    public static final String FIRST_NAME ="First Name";
    public static final String LAST_NAME="Last Name";
    public static final String  MIDDLE_NAME="Middle Name";
    public static final String  CONTRACTOR_COMPANY_NAME="Contractor Company Name";
    public static final String BUREAU_ID="Bureau ID";
    public static final String BUREAU_DESCRIPTION="Bureau Description";
    public static final String POSITION_SENSITIVITY="Position Sensitivity";
    public static final String COR_NAME="COR Name";
    public static final String EMP_TYPE="Employee Type";
    public static final char COMMA_DELIMITER = ',';
    public static final String SFTP_CLIENT_NOTCONNECTED = "SFTP Server Connection Error";
    public static final String SFTP = "sftp";
}
