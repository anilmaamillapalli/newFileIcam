package org.ed.icam.oim.utils;

import com.csvreader.CsvReader;
import com.jcraft.jsch.*;
import groovy.json.internal.Charsets;
import oracle.core.ojdl.logging.ODLLogger;
import oracle.iam.identity.exception.NoSuchUserException;
import oracle.iam.identity.exception.UserModifyException;
import oracle.iam.identity.exception.UserSearchException;
import oracle.iam.identity.exception.ValidationFailedException;
import oracle.iam.identity.usermgmt.api.UserManager;
import oracle.iam.identity.usermgmt.vo.User;
import oracle.iam.platform.entitymgr.vo.SearchCriteria;
import oracle.iam.scheduler.vo.TaskSupport;
import org.ed.icam.oim.utils.constants.OIMConstants;
import org.ed.icam.oim.utils.entity.Contractor;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PersonnelHandleScheduler  extends TaskSupport {
    private static final Logger logger = ODLLogger.getLogger(PersonnelHandleScheduler.class.getName());
    private JSch jsch = null;
    private Session session = null;
    private Channel channel = null;
    private ChannelSftp csftp = null;


    @Override
    public void execute(HashMap staticParam) throws Exception {
        logger.log(Level.INFO,"===================Executing execute method of SFTPSchedulerFileProcess==========================");
        String sftpHostName=(String)staticParam.get("SFTP Host Name");
        logger.log(Level.INFO,"SFTP Host Name ::"+sftpHostName);

        String sftpUserName = (String)staticParam.get("SFTP User Name");
        logger.log(Level.INFO,"SFTP User Name::"+sftpUserName);

        String sftpPassword = (String)staticParam.get("SFTP Password");

        String sftpHostKey=(String)staticParam.get("SFTP HostKey");
        logger.log(Level.INFO,"SFTP HostKey Known Host::"+sftpHostKey);

        String errorLocalFilePath= (String)staticParam.get("Error Local File Path");
        logger.log(Level.INFO,"Error Local File Path::"+errorLocalFilePath);

        String LocalFilePath= (String)staticParam.get("Local File Path");
        logger.log(Level.INFO,"Destination File Path::"+LocalFilePath);

        String sftpRemoteFilePath= (String)staticParam.get("Sftp Remote File Path");
        logger.log(Level.INFO,"Sftp Remote File Path::"+sftpRemoteFilePath);

        connect(sftpHostName,sftpUserName,sftpPassword,sftpHostKey);
        HashMap<Integer, String> totalNoOfCSVFilesInMap = checkCSVListAndSaveInLocal(sftpRemoteFilePath, LocalFilePath);
        List<Contractor> contractorInformationFromCSVFile = getContractorInformationFromCSVFile(totalNoOfCSVFilesInMap);
        searchUpdateUser(contractorInformationFromCSVFile,errorLocalFilePath);
        disconnect();

    }

    /**
     * This method will establishes the connection to SFTP Remote server and create a connection object to this scheduler job.
     * @param hostName
     * @param userName
     * @param password
     * @param knownHosts
     * @throws JSchException
     */

    public void connect(String hostName,String userName,String password,String knownHosts)  {
        logger.log(Level.INFO,"======Entered into Connect Method to connect with SFTP Remote Server =====");
        try {
            Properties config = new Properties();
            jsch = new JSch();
            jsch.setKnownHosts(knownHosts);
            session = jsch.getSession(userName, hostName);
            session.setConfig("StrictHostKeyChecking","no");
            session.setPassword(password);
            session.setConfig(config);
            session.connect();
            channel = session.openChannel("sftp");
            channel.connect();
            logger.log(Level.INFO,"======Connect to the  SFTP Remote Server =====");
            csftp = (ChannelSftp) channel;
        } catch (JSchException e) {
            logger.log(Level.SEVERE, "Exception ::" + e.getMessage());
        }
        logger.log(Level.INFO,"======Exiting from Connect Method  =====");
    }

    /**
     * Uploads a file to the sftp server
     * @param sourceFile String path to sourceFile
     * @param destinationFile String path on the remote server
     * @throws SFTPException if connection and channel are not available or if an error occurs during upload.
     */
    public void uploadFile(String sourceFile, String destinationFile) throws SFTPException {
        if (csftp == null || session == null || !session.isConnected() || !csftp.isConnected()) {
            throw new SFTPException("Connection to server is closed. Open it first.");
        }
        try {
            logger.info("Uploaded file to server");
            csftp.put(sourceFile, destinationFile);
            logger.info("Uploaded Successfull.");
        } catch (Exception e) {
            throw new  SFTPException(e.getMessage());
        }
    }

    /**
     * Download  a file from the sftp server
     * @param sourceFile String path to Remote Server sourceFile
     * @param destinationFile String path on the local folder
     * @throws SFTPException if connection and channel are not available or if an error occurs during upload.
     */
    public void retrieveFile(String sourceFile, String destinationFile) throws SFTPException {
        if (csftp == null || session == null || !session.isConnected() || !csftp.isConnected()) {
            throw new SFTPException("Connection to server is closed. Open it first.");
        }
        try {
            logger.info("Downloading file to server");
            csftp.get(sourceFile, destinationFile);
            logger.info("Download successfull.");
        } catch (Exception e) {
            throw new SFTPException(e.getMessage());
        }
    }

    /**
     * This method will Disconnection SFTP Server Connection Object.
     */
    public  void disconnect() {
        if (csftp != null) {
            logger.info("Disconnecting sftp channel");
            csftp.disconnect();
        }
        if (channel != null) {
            logger.info("Disconnecting channel");
            channel.disconnect();
        }
        if (session != null) {
            logger.info("Disconnecting session");
            session.disconnect();
        }
    }

    public void deleteCsvFilesFromFolder(String folderPath) throws IOException {
        File directoryPath= new File(folderPath);
        File filesList[] = directoryPath.listFiles();
        for(File fileName: filesList){
            String fqpfName=fileName.getAbsolutePath();
            if(fqpfName.contains(".csv")){
                Path path = Paths.get(fqpfName);
                Files.delete(path);
            }

        }
    }




    /**
     *Description: This method will take input as Remote SFTP CSV Files path, and check each files whether a CSV File or not,
     * If CSV file, copy to the local environment.
     * @param remoteFolderPath , localFilePath
     * @return List<HashMap<String,String>>
     * @throws SFTPException
     */
    public HashMap<Integer,String> checkCSVListAndSaveInLocal(String remoteFolderPath, String localFilePath) throws SFTPException {
        logger.log(Level.INFO,"======Entered into checkCSVListAndSaveInLocal  Method  to get all the CSV File in SFTP Remote Server =====");
        if (csftp == null || session == null || !session.isConnected() || !csftp.isConnected()) {
            logger.log(Level.SEVERE,"Exception ::"+"Connection to server is closed. Open it first");
            throw new SFTPException("Connection to server is closed. Open it first.");
        }
        HashMap<Integer,String> localFileMap= new HashMap<>();
        try{
            Vector<ChannelSftp.LsEntry> entries = csftp.ls(remoteFolderPath);//"/export/sftp/icam_dev");
            int i =0;
            for(ChannelSftp.LsEntry entrie: entries){
                String csvFileName=entrie.getFilename();
                if(csvFileName.contains(".csv") ) {
                    csftp.get(csvFileName, localFilePath+csvFileName);
                    i= i+1;
                    localFileMap.put(i,localFilePath+csvFileName);
                 }
            }
        }catch(Exception e){
            logger.log(Level.SEVERE,"Exception ::"+e.getMessage());
            throw new SFTPException(e.getMessage());
        }
        logger.log(Level.INFO,"======Exiting  from checkCSVListAndSaveInLocal  Method  =====");
        return localFileMap;
    }

    @Override
    public HashMap getAttributes() {
        return null;
    }

    @Override
    public void setAttributes() {
    }


    /**
     * @param mapOfFiles
     * @return
     * Description: This method takes InputStream and generates List object of Contractors.
     */
    private List<Contractor> getContractorInformationFromCSVFile(HashMap<Integer,String> mapOfFiles) {
        List<Contractor> contactorList = null;
        for(Map.Entry<Integer, String> entries : mapOfFiles.entrySet()) {
            String FQfileName = entries.getValue();
            try {
                InputStream is = new FileInputStream(FQfileName);
                CsvReader contractorFileReader = new CsvReader(is, OIMConstants.COMMA_DELIMITER, Charsets.UTF_8);

                try {
                    contractorFileReader.readHeaders();
                    contactorList = new ArrayList<Contractor>();
                    Contractor contractor;
                    while (contractorFileReader.readRecord()) {
                        contractor = new Contractor();
                        contractor.setPersonalHandle(OIMConstants.PERSONNEL_HANDLE);
                        contractor.setContractorEmpStatus(OIMConstants.CONTRACTOR_EMP_STATUS);
                        contractor.setFirstName(OIMConstants.FIRST_NAME);
                        contractor.setLastName(OIMConstants.LAST_NAME);
                        contractor.setMiddleName(OIMConstants.MIDDLE_NAME);
                        contractor.setContractorCompany(OIMConstants.CONTRACTOR_COMPANY_NAME);
                        contractor.setBureauId(OIMConstants.BUREAU_ID);
                        contractor.setBureauDescription(OIMConstants.BUREAU_DESCRIPTION);
                        contractor.setPositionSensitivity(OIMConstants.POSITION_SENSITIVITY);
                        contractor.setCorName(OIMConstants.COR_NAME);
                        contractor.setEmpType(OIMConstants.EMP_TYPE);
                        contactorList.add(contractor);
                    }
                    System.out.println("List of user Information " + contactorList.toString());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return contactorList;
    }

    /**
     * @param contractorList
     * @throws UserSearchException
     * @throws ValidationFailedException
     * @throws NoSuchUserException
     * @throws UserModifyException
     * Description:  This method Searches User Object in OIM If found call modify user methods for Updating user Personnel Handle Number and other attributes.
     */
    public static void  searchUpdateUser(List<Contractor> contractorList,String errorLocalFilePath)  {
        SearchCriteria criteriaFirstName, criteriaLastName,criteriaResult;
        for (Contractor contractor: contractorList) {
            criteriaFirstName= new SearchCriteria("First Name",contractor.getFirstName(),SearchCriteria.Operator.EQUAL);
            criteriaLastName= new SearchCriteria("Last Name",contractor.getLastName(),SearchCriteria.Operator.EQUAL);
            criteriaResult= new SearchCriteria(criteriaFirstName, criteriaLastName, SearchCriteria.Operator.AND);

            //udpate user info
            Set fetchAttr= new HashSet();
            fetchAttr.add("First Name");
            fetchAttr.add("Last Name");
            fetchAttr.add("Personnel Handle");
            UserManager userManager = OIMUtils.BaseClient().getService(UserManager.class);

            List<User> oimUserList = null;
            try {
                oimUserList = userManager.search(criteriaResult, fetchAttr, null);
            } catch (UserSearchException e) {
                e.printStackTrace();
            }

           // checkfor the empty if yes
            if (oimUserList.isEmpty()){
                 createFileInLocalPath(errorLocalFilePath,contractor,"User Does not exist in OIM");
                //write CSV File user in the new Local CSV File  saying use does not exist in OIM. with description
            }else if (oimUserList.size() > 1){
                createFileInLocalPath(errorLocalFilePath,contractor,"More then one user exist in OIM");
                //more than two user found in  OIM for the given user from CSV File.
                //write the user information to the file::  with description
                //check with chandra, what if the same record comes in a file  for the processing and Handle number is already presisted in the user profile.
                //Create CSV File
                //Enter this contractor's record to the file. because multiple records find in OIM.
            }else if (OIMUtils.isEmpty(oimUserList.get(1).getAttribute("Personnel Handle No").toString())){
                User user = oimUserList.get(1);
                //passing to below method
                modifyUserAttributes(user.getId(),contractor.getPersonalHandle(),contractor.getBureauId(),contractor.getContractorCompany());
            }else if (!OIMUtils.isEmpty(oimUserList.get(1).getAttribute("Personnel Handle No").toString())){
                createFileInLocalPath(errorLocalFilePath,contractor,"Personnel Handle Number is already exist to the given user");
                //check OIM Personnal Handle Number with  CSV file Personnal Handle Number,  if equal do nothing  else report it to the local CSV File wlith description
                // check with chandra,
            }
        }
    }
    /**
     * @param id
     * @param personalHandle
     * @param bureauId
     * @param contractorCompany
     * @throws ValidationFailedException
     * @throws NoSuchUserException
     * @throws UserModifyException
     * Description : This method is called from the caller in the loop to update user profile.
     */
    private static void modifyUserAttributes(String id, String personalHandle, String bureauId, String contractorCompany) {
        //this is the second time we are using UserManager.class can we make it as class level verable ....Think
        UserManager userManager = OIMUtils.BaseClient().getService(UserManager.class);
        User updateUser= new User(id);
        updateUser.setAttribute("AttributeName",personalHandle);
        updateUser.setAttribute("attributeName",bureauId);
        updateUser.setAttribute("attributeName",contractorCompany);
        try {
            userManager.modify(updateUser);
        } catch (ValidationFailedException e) {
            e.printStackTrace();
        } catch (UserModifyException e) {
            e.printStackTrace();
        } catch (NoSuchUserException e) {
            e.printStackTrace();
        }
    }

    public static void createFileInLocalPath(String errorLocalFilePath,Contractor contractor,String description)  {
        File file= new File(errorLocalFilePath+"NonProcessedRecords.csv");
        PrintWriter pw= null;
        if(!file.exists()){
            try {
                file.createNewFile();
                pw= new PrintWriter(file);
                pw.println("Personnel Handle,Contractor Employment Status,First Name,Last Name,Middle Name,Contractor Company Name,Bureau ID,Bureau Description,Position Sensitivity,COR Name,Employee Type,Error Description");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            pw= new PrintWriter(file);
            pw.print(contractor.getPersonalHandle());
            pw.print(contractor.getContractorEmpStatus());
            pw.print(contractor.getFirstName());
            pw.print(contractor.getLastName());
            pw.print(contractor.getMiddleName());
            pw.print(contractor.getContractorCompany());
            pw.print(contractor.getBureauId());
            pw.print(contractor.getBureauDescription());
            pw.print(contractor.getPositionSensitivity());
            pw.print(contractor.getCorName());
            pw.print(contractor.getEmpType());
            pw.print(description);
            pw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {

    }




}
